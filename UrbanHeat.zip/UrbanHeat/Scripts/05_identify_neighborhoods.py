"""
Step 7: look up real neighborhood names for the priority cells identified
in 04_map_predictions.py, using OpenStreetMap's free Nominatim geocoder.

Requires: pip install geopy

Run:
    python 05_identify_neighborhoods.py
"""

import time

import geopandas as gpd
import pandas as pd
from geopy.geocoders import Nominatim

# ---- EDIT THESE ----
PRIORITY_CSV = "../data/priority_cells.csv"
GEOMETRY_PATH = "../data/grid_features_geometry.gpkg"
OUT_CSV = "../data/priority_cells_named.csv"
# ---------------------

if __name__ == "__main__":
    priority = pd.read_csv(PRIORITY_CSV)
    geom = gpd.read_file(GEOMETRY_PATH)

    gdf = geom.merge(priority, on="cell_id", how="inner")
    centroids = gdf.geometry.centroid  # already in EPSG:4326 (lat/lon) from step 3

    geolocator = Nominatim(user_agent="urbancool-uhi-project")

    names = []
    for i, point in enumerate(centroids):
        try:
            # Nominatim wants (lat, lon); geometry gives (x=lon, y=lat)
            location = geolocator.reverse((point.y, point.x), zoom=16, language="en")
            address = location.raw.get("address", {}) if location else {}
            # try a few likely keys in order of specificity
            name = (
                address.get("suburb")
                or address.get("neighbourhood")
                or address.get("residential")
                or address.get("road")
                or address.get("city_district")
                or "unknown"
            )
        except Exception as e:
            name = f"lookup_failed ({e})"
        names.append(name)
        print(f"  [{i+1}/{len(centroids)}] cell {gdf.iloc[i]['cell_id']} -> {name}")
        time.sleep(1)  # Nominatim's free usage policy: max 1 request/second

    gdf["neighborhood"] = names
    gdf["lat"] = centroids.y
    gdf["lon"] = centroids.x

    out_df = gdf.drop(columns="geometry")
    out_df.to_csv(OUT_CSV, index=False)
    print(f"\nSaved named priority cells to {OUT_CSV}")
    print(out_df[["cell_id", "neighborhood", "uhi_intensity", "ndvi"]].to_string(index=False))
