"""
Step 6: map predictions back onto the city and identify priority zones
for green space / cooling infrastructure.

Requires the geometry file saved by 02_build_grid_features.py
(../data/grid_features_geometry.gpkg) plus grid_features.csv.

Run:
    python 04_map_predictions.py
"""

import geopandas as gpd
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.ensemble import RandomForestRegressor

# ---- EDIT THESE ----
DATA_PATH = "../data/grid_features.csv"
GEOMETRY_PATH = "../data/grid_features_geometry.gpkg"
FEATURE_COLS = ["ndvi", "landcover", "elevation", "era5"]
TARGET_COL = "lst"
OUT_MAP_PNG = "../data/uhi_priority_map.png"
OUT_PRIORITY_CSV = "../data/priority_cells.csv"
TOP_N_PRIORITY = 30  # how many hottest/least-green cells to flag as priorities
# ---------------------

if __name__ == "__main__":
    df = pd.read_csv(DATA_PATH)
    geom = gpd.read_file(GEOMETRY_PATH)

    df = df.dropna(subset=FEATURE_COLS + [TARGET_COL])

    # exclude water bodies (ESA WorldCover class 80) -- otherwise the huge land/sea
    # temperature contrast swamps the color scale and hides neighborhood-level variation
    WATER_CLASS = 80
    n_before = len(df)
    df = df[df["landcover"] != WATER_CLASS]
    print(f"Excluded {n_before - len(df)} water cells, {len(df)} land cells remain")

    gdf = geom.merge(df, on="cell_id", how="inner")

    # train on all available data (this script is for visualization, not evaluation,
    # so no train/test split needed here -- that's what 03_train_model.py is for)
    X = gdf[FEATURE_COLS]
    y = gdf[TARGET_COL]
    model = RandomForestRegressor(n_estimators=300, random_state=0)
    model.fit(X, y)
    gdf["predicted_lst"] = model.predict(X)

    # UHI intensity = how much hotter a cell is than the city average
    city_mean = gdf["predicted_lst"].mean()
    gdf["uhi_intensity"] = gdf["predicted_lst"] - city_mean

    # --- Map 1: UHI intensity choropleth ---
    # Clip color scale to the 2nd-98th percentile so a few extreme outlier cells
    # don't stretch the whole color range and wash out normal neighborhood variation.
    vmin, vmax = gdf["uhi_intensity"].quantile([0.02, 0.98])
    fig, ax = plt.subplots(figsize=(10, 10))
    gdf.plot(
        column="uhi_intensity", cmap="RdYlGn_r", legend=True, ax=ax,
        edgecolor="none", vmin=vmin, vmax=vmax,
        legend_kwds={"label": "UHI intensity (deg C above land average)"},
    )
    ax.set_title("Predicted urban heat island intensity (land only)")
    ax.set_axis_off()
    plt.tight_layout()
    plt.savefig(OUT_MAP_PNG, dpi=150)
    print(f"Saved map to {OUT_MAP_PNG}")

    # --- Priority zones: hottest cells with the least vegetation ---
    # Combine both signals into one score so we flag cells that are BOTH hot AND green-deficient,
    # not just the hottest cells overall (which might already have decent tree cover nearby).
    gdf["heat_rank"] = gdf["uhi_intensity"].rank(ascending=False)  # 1 = hottest
    gdf["greenery_rank"] = gdf["ndvi"].rank(ascending=True)        # 1 = least vegetation
    gdf["priority_score"] = gdf["heat_rank"] + gdf["greenery_rank"]  # lower = higher priority

    priority = gdf.nsmallest(TOP_N_PRIORITY, "priority_score")[
        ["cell_id", "uhi_intensity", "ndvi", "landcover", "predicted_lst", "priority_score"]
    ].sort_values("priority_score")

    priority.to_csv(OUT_PRIORITY_CSV, index=False)
    print(f"Saved top {TOP_N_PRIORITY} priority cells to {OUT_PRIORITY_CSV}")
    print("\nTop 10 priority cells (hottest + least green):")
    print(priority.head(10).to_string(index=False))
