import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler
from tensorflow import keras
from tensorflow.keras import layers


DATA_PATH = "../data/grid_features.csv"
USE_SYNTHETIC = False  # flip to False once you have real data
FEATURE_COLS = ["ndvi", "landcover", "elevation", "era5"]
TARGET_COL = "lst"


def make_synthetic_data(n=1500, seed=0):
    """Fake city grid: more vegetation and elevation -> cooler; more built-up -> hotter."""
    rng = np.random.default_rng(seed)
    x = rng.uniform(0, 5000, n)
    y = rng.uniform(0, 5000, n)
    ndvi = np.clip(rng.normal(0.4, 0.2, n), -0.1, 0.9)
    landcover = rng.integers(0, 5, n)  # 0=water 1=tree 2=grass 3=built 4=bare
    elevation = rng.normal(50, 20, n)
    era5 = rng.normal(28, 1.5, n)  # ambient air temp
    built_up_bonus = (landcover == 3).astype(float) * 3.0
    lst = 30 - 8 * ndvi - 0.02 * elevation + 0.5 * era5 + built_up_bonus + rng.normal(0, 1, n)
    return pd.DataFrame(
        {"x": x, "y": y, "ndvi": ndvi, "landcover": landcover,
         "elevation": elevation, "era5": era5, "lst": lst}
    )


def spatial_train_test_split(df, block_size_m=1000, test_blocks_mod=5):
    """Split using a checkerboard of spatial blocks instead of a single left/right
    cut. This still holds out cells the model never saw nearby (avoiding leakage),
    but spreads the test set across the whole city rather than one contiguous
    region, which avoids extreme distribution shift between train and test."""
    block_x = (df["x"] // block_size_m).astype(int)
    block_y = (df["y"] // block_size_m).astype(int)
    is_test = ((block_x + block_y) % test_blocks_mod) == 0
    return df[~is_test], df[is_test]


def evaluate(name, y_true, y_pred):
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    mae = mean_absolute_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    print(f"{name:>15} | RMSE={rmse:.3f}  MAE={mae:.3f}  R2={r2:.3f}")


if __name__ == "__main__":
    if USE_SYNTHETIC:
        print("Using synthetic data (set USE_SYNTHETIC=False once real data is ready)\n")
        df = make_synthetic_data()
    else:
        df = pd.read_csv(DATA_PATH)

    before = len(df)
    df = df.dropna(subset=FEATURE_COLS + [TARGET_COL])
    dropped = before - len(df)
    if dropped:
        print(f"Dropped {dropped} rows with missing values (out of {before})\n")

    train_df, test_df = spatial_train_test_split(df)
    X_train, y_train = train_df[FEATURE_COLS], train_df[TARGET_COL]
    X_test, y_test = test_df[FEATURE_COLS], test_df[TARGET_COL]

    scaler = StandardScaler()
    X_train_s = scaler.fit_transform(X_train)
    X_test_s = scaler.transform(X_test)

    # --- Baseline: Random Forest ---
    rf = RandomForestRegressor(n_estimators=300, random_state=0)
    rf.fit(X_train, y_train)
    evaluate("Random Forest", y_test, rf.predict(X_test))
    print("Feature importances:", dict(zip(FEATURE_COLS, rf.feature_importances_.round(3))))

    # --- Neural network: MLP ---
    model = keras.Sequential([
        layers.Input(shape=(len(FEATURE_COLS),)),
        layers.Dense(64, activation="relu"),
        layers.Dropout(0.2),
        layers.Dense(32, activation="relu"),
        layers.Dense(16, activation="relu"),
        layers.Dense(1),
    ])
    model.compile(optimizer="adam", loss="mse")
    early_stop = keras.callbacks.EarlyStopping(
        monitor="val_loss", patience=10, restore_best_weights=True
    )
    model.fit(
        X_train_s, y_train, validation_split=0.15, epochs=150, batch_size=32,
        callbacks=[early_stop], verbose=0,
    )

    print()
    evaluate("Neural Net", y_test, model.predict(X_test_s, verbose=0).flatten())
