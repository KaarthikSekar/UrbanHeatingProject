import os
import ee
import geemap


CITY_GEOJSON = "../data/city_boundary.geojson"  
START_DATE = "2024-06-01"
END_DATE = "2024-08-31"
OUT_DIR = "../data/rasters"
SCALE_METERS = 100 


ee.Initialize(project="urbancool-uhi")  # your GEE project ID

city = geemap.geojson_to_ee(CITY_GEOJSON)
region = city.geometry()

# 1. Land surface temperature (target variable) — MODIS, Kelvin*0.02 scale factor
lst_col = (
    ee.ImageCollection("MODIS/061/MOD11A2")
    .filterDate(START_DATE, END_DATE)
    .filterBounds(region)
    .select("LST_Day_1km")
)
lst = lst_col.mean().multiply(0.02).subtract(273.15).rename("LST_celsius")

# 2. NDVI — Sentinel-2 surface reflectance
def add_ndvi(img):
    ndvi = img.normalizedDifference(["B8", "B4"]).rename("NDVI")
    return img.addBands(ndvi)

s2 = (
    ee.ImageCollection("COPERNICUS/S2_SR_HARMONIZED")
    .filterDate(START_DATE, END_DATE)
    .filterBounds(region)
    .filter(ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE", 60))  # relaxed for monsoon-season coverage
    .map(add_ndvi)
)
print("Sentinel-2 scenes found:", s2.size().getInfo())
ndvi = s2.select("NDVI").median()  # median is more cloud-robust than mean

# 3. Land cover — ESA WorldCover (single most recent version)
landcover = ee.ImageCollection("ESA/WorldCover/v200").first().select("Map").rename("landcover")

# 4. Elevation — SRTM
elevation = ee.Image("USGS/SRTMGL1_003").select("elevation")

# 5. Weather — ERA5-Land monthly aggregated (covers recent dates, unlike ECMWF/ERA5/MONTHLY
# which only goes up to mid-2020). Band units: temperature_2m is in Kelvin.
era5 = (
    ee.ImageCollection("ECMWF/ERA5_LAND/MONTHLY_AGGR")
    .filterDate(START_DATE, END_DATE)
    .filterBounds(region)
    .select(["temperature_2m", "total_precipitation_sum"])
    .mean()
)

layers = {
    "lst": lst,
    "ndvi": ndvi,
    "landcover": landcover,
    "elevation": elevation,
    "era5": era5,
}

os.makedirs(OUT_DIR, exist_ok=True)

for name, img in layers.items():
    out_path = f"{OUT_DIR}/{name}.tif"
    print(f"Exporting {name} -> {out_path}")
    try:
        n_bands = img.bandNames().size().getInfo()
        if n_bands == 0:
            print(f"  FAILED: {name} -> image has 0 bands (empty source collection, check filters/date range)")
            continue
        geemap.ee_export_image(
            img.clip(region),
            filename=out_path,
            scale=SCALE_METERS,
            region=region,
            file_per_band=False,
        )
        print(f"  OK: {name}")
    except Exception as e:
        print(f"  FAILED: {name} -> {e}")
        print("  (continuing with remaining layers)")

print("Done. Check data/rasters/ for the GeoTIFFs.")
