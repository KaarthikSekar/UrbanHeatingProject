import geopandas as gpd
import numpy as np
import rasterio
from rasterstats import zonal_stats
from shapely.geometry import box


CITY_GEOJSON = "../data/city_boundary.geojson"
RASTER_DIR = "../data/rasters"
CELL_SIZE_METERS = 250
OUT_CSV = "../data/grid_features.csv"
LAYERS = ["lst", "ndvi", "landcover", "elevation", "era5"]


def make_grid(boundary_gdf, cell_size):
    """Build a fishnet grid of square cells covering the city boundary."""
    boundary_gdf = boundary_gdf.to_crs(epsg=3857)  # meters
    minx, miny, maxx, maxy = boundary_gdf.total_bounds
    cells = []
    x = minx
    while x < maxx:
        y = miny
        while y < maxy:
            cells.append(box(x, y, x + cell_size, y + cell_size))
            y += cell_size
        x += cell_size
    grid = gpd.GeoDataFrame({"geometry": cells}, crs="EPSG:3857")
    grid = gpd.overlay(grid, boundary_gdf, how="intersection")  # clip to city shape
    grid["cell_id"] = range(len(grid))
    return grid.to_crs(epsg=4326)  # back to lat/lon for raster matching


def add_zonal_mean(grid, raster_path, col_name):
    stats = zonal_stats(grid.geometry, raster_path, stats=["mean"], nodata=np.nan)
    grid[col_name] = [s["mean"] for s in stats]
    return grid


if __name__ == "__main__":
    city = gpd.read_file(CITY_GEOJSON)
    grid = make_grid(city, CELL_SIZE_METERS)
    print(f"Built grid with {len(grid)} cells")

    for layer in LAYERS:
        raster_path = f"{RASTER_DIR}/{layer}.tif"
        try:
            grid = add_zonal_mean(grid, raster_path, layer)
            print(f"Added {layer}")
        except Exception as e:
            print(f"Skipped {layer}: {e}")

    # drop cells with no valid LST (usually water bodies or edge slivers)
    grid = grid.dropna(subset=["lst"])

    # add centroid coordinates in meters (needed for the spatial train/test split later)
    centroids = grid.to_crs(epsg=3857).geometry.centroid
    grid["x"] = centroids.x
    grid["y"] = centroids.y

    # save geometry separately (needed later for mapping predictions back onto the city)
    geom_out = OUT_CSV.replace(".csv", "_geometry.gpkg")
    grid[["cell_id", "geometry"]].to_file(geom_out, driver="GPKG")
    print(f"Saved cell geometry to {geom_out}")

    out_df = grid.drop(columns="geometry")
    out_df.to_csv(OUT_CSV, index=False)
    print(f"Saved {len(out_df)} rows to {OUT_CSV}")
